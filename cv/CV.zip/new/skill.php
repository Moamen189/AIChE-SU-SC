<?php

	/*include 'config/config.php';
	$output = '';
	if(isset($_POST['query'])) {
		$search = $_POST['query'];
		$sql = "SELECT * FROM skills WHERE skill LIKE '%".$search."%'";
		$stmt = $con->prepare($sql);
		//$stmt->bind_param('ss',$search,PDO::PARAM_STR);
		$stmt->execute();
		$result = $stmt->fetch();

	};
	if($result) {
		foreach ($result as $value) {
			
			$output .= "<div class='skill'><div>" +  $value['skill'] + "</div></div>";
		}
	
	}
	echo $output;
	
*/
?>