$(function () {
	'use strict';
	// confirmation on delete
	
	$('.confirm').click(function () {
		return confirm('Are you sure?');
	});
  
});    