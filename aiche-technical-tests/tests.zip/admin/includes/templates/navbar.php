<nav class="navbar navbar-inverse">
  <div class="container">
      <ul class="nav navbar-nav navbar-right">
            <li><a href=" logout.php">Logout</a></li>
        </ul>
    </div>

  </div>
</nav>